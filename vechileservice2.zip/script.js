// Service prices
const servicePrices = {
    "Engine Oil Change": 3000,
    "Brake Inspection": 2000,
    "Wheel Alignment": 3500,
    "Computer Diagnosis": 2500,
    "Full Service": 8000,

    // Individualized requirement - Last digit 4
    "Tyre Balancing": 2000
};


// Get form elements
const serviceForm = document.getElementById("serviceForm");

const serviceCheckboxes =
    document.querySelectorAll('input[name="services[]"]');

const totalCost =
    document.getElementById("totalCost");

const selectedServices =
    document.getElementById("selectedServices");

const serviceCount =
    document.getElementById("serviceCount");

const vehicleType =
    document.getElementById("vehicle_type");

const yearInput =
    document.getElementById("year");

const ageWarning =
    document.getElementById("ageWarning");

const vehicleInfo =
    document.getElementById("vehicleInfo");


// --------------------------------------------------
// FUNCTION 1: Calculate service cost
// --------------------------------------------------

function calculateServiceCost() {

    let total = 0;

    let selected = [];

    serviceCheckboxes.forEach(function (service) {

        if (service.checked) {

            const serviceName = service.value;

            const price =
                servicePrices[serviceName];

            total += price;

            selected.push(serviceName);
        }

    });


    // Update service count
    serviceCount.textContent = selected.length;


    // Update selected service list
    selectedServices.innerHTML = "";


    if (selected.length === 0) {

        selectedServices.innerHTML =
            "<li>No service selected.</li>";

    } else {

        selected.forEach(function (service) {

            const listItem =
                document.createElement("li");

            listItem.textContent =
                service + " - KSh " +
                servicePrices[service].toLocaleString();

            selectedServices.appendChild(listItem);

        });

    }


    // Update total
    totalCost.textContent =
        "KSh " + total.toLocaleString();

}


// --------------------------------------------------
// FUNCTION 2: Check vehicle age
// --------------------------------------------------

function checkVehicleAge() {

    const year =
        parseInt(yearInput.value);

    const currentYear =
        new Date().getFullYear();


    ageWarning.textContent = "";


    if (!yearInput.value) {
        return;
    }


    if (year < 1900 || year > currentYear) {

        ageWarning.textContent =
            "Please enter a reasonable year of manufacture.";

        ageWarning.style.color = "#d90429";

        return;
    }


    const age =
        currentYear - year;


    if (age > 15) {

        ageWarning.textContent =
            "⚠ Warning: This vehicle is more than 15 years old. " +
            "A detailed inspection is recommended.";

        ageWarning.style.color = "#d97706";

    } else {

        ageWarning.textContent =
            "Vehicle age: " + age + " years.";

        ageWarning.style.color = "#087f5b";
    }

}


// --------------------------------------------------
// FUNCTION 3: Vehicle type information
// --------------------------------------------------

function showVehicleInformation() {

    const type =
        vehicleType.value;


    if (type === "Saloon Car") {

        vehicleInfo.textContent =
            "Suitable services include oil changes, brake inspection and alignment.";

    }

    else if (type === "SUV") {

        vehicleInfo.textContent =
            "SUV owners may consider alignment, tyre balancing and full service.";

    }

    else if (type === "Pickup") {

        vehicleInfo.textContent =
            "Pickup vehicles should receive regular engine and brake maintenance.";

    }

    else if (type === "Van") {

        vehicleInfo.textContent =
            "Regular servicing is recommended for vans used for transportation.";

    }

    else {

        vehicleInfo.textContent = "";

    }

}


// --------------------------------------------------
// FUNCTION 4: Form validation
// --------------------------------------------------

function validateServiceForm() {

    let valid = true;


    // Get input values
    const name =
        document.getElementById("customer_name").value.trim();

    const phone =
        document.getElementById("phone").value.trim();

    const email =
        document.getElementById("email").value.trim();

    const registration =
        document.getElementById("registration").value.trim();

    const year =
        parseInt(document.getElementById("year").value);


    const currentYear =
        new Date().getFullYear();


    // Clear previous errors
    document.getElementById("nameError").textContent = "";
    document.getElementById("phoneError").textContent = "";
    document.getElementById("emailError").textContent = "";
    document.getElementById("registrationError").textContent = "";
    document.getElementById("yearError").textContent = "";
    document.getElementById("serviceError").textContent = "";


    // Customer name
    if (name === "") {

        document.getElementById("nameError").textContent =
            "Customer name is required.";

        valid = false;
    }


    // Phone
    const phonePattern =
        /^[0-9]{10}$/;


    if (!phonePattern.test(phone)) {

        document.getElementById("phoneError").textContent =
            "Phone number must contain exactly 10 digits.";

        valid = false;
    }


    // Email
    const emailPattern =
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/;


    if (!emailPattern.test(email)) {

        document.getElementById("emailError").textContent =
            "Please enter a valid email address.";

        valid = false;
    }


    // Registration
    if (registration === "") {

        document.getElementById("registrationError").textContent =
            "Vehicle registration number is required.";

        valid = false;
    }


    // Year
    if (
        isNaN(year) ||
        year < 1900 ||
        year > currentYear
    ) {

        document.getElementById("yearError").textContent =
            "Enter a reasonable year between 1900 and " +
            currentYear + ".";

        valid = false;
    }


    // Services
    let numberOfServices = 0;


    serviceCheckboxes.forEach(function (service) {

        if (service.checked) {
            numberOfServices++;
        }

    });


    if (numberOfServices === 0) {

        document.getElementById("serviceError").textContent =
            "Please select at least one service.";

        valid = false;
    }


    return valid;

}


// --------------------------------------------------
// EVENT 1: Service selection
// --------------------------------------------------

serviceCheckboxes.forEach(function (service) {

    service.addEventListener(
        "change",
        calculateServiceCost
    );

});


// --------------------------------------------------
// EVENT 2: Vehicle type change
// --------------------------------------------------

vehicleType.addEventListener(
    "change",
    showVehicleInformation
);


// --------------------------------------------------
// EVENT 3: Year input
// --------------------------------------------------

yearInput.addEventListener(
    "input",
    checkVehicleAge
);


// --------------------------------------------------
// EVENT 4: Form submit
// --------------------------------------------------

serviceForm.addEventListener(
    "submit",
    function (event) {

        if (!validateServiceForm()) {

            event.preventDefault();

        }

    }
);


// --------------------------------------------------
// Reset dynamic information
// --------------------------------------------------

function resetFormDisplay() {

    setTimeout(function () {

        serviceCount.textContent = "0";

        totalCost.textContent = "KSh 0";

        selectedServices.innerHTML =
            "<li>No service selected.</li>";

        vehicleInfo.textContent = "";

        ageWarning.textContent = "";

    }, 10);

}