<?php

// --------------------------------------------------
// AutoCare Garage
// Vehicle Service Booking System
// PHP Processing File
// --------------------------------------------------


// Make sure the form was submitted using POST
if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    die("Invalid request. Please submit the service booking form.");
}


// --------------------------------------------------
// Retrieve customer information
// --------------------------------------------------

$customer_name = trim($_POST["customer_name"] ?? "");

$phone = trim($_POST["phone"] ?? "");

$email = trim($_POST["email"] ?? "");


// --------------------------------------------------
// Retrieve vehicle information
// --------------------------------------------------

$registration = trim($_POST["registration"] ?? "");

$vehicle_type = trim($_POST["vehicle_type"] ?? "");

$vehicle_model = trim($_POST["vehicle_model"] ?? "");

$year = intval($_POST["year"] ?? 0);

$service_date = trim($_POST["service_date"] ?? "");


// --------------------------------------------------
// Retrieve selected services
// --------------------------------------------------

$services = $_POST["services"] ?? [];


// --------------------------------------------------
// Server-side validation
// --------------------------------------------------

$errors = [];


// Customer name
if ($customer_name === "") {

    $errors[] = "Customer name is required.";
}


// Phone
if (!preg_match("/^[0-9]{10}$/", $phone)) {

    $errors[] =
        "Phone number must contain exactly 10 digits.";
}


// Email
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

    $errors[] =
        "Please provide a valid email address.";
}


// Registration
if ($registration === "") {

    $errors[] =
        "Vehicle registration number is required.";
}


// Vehicle type
$allowedVehicleTypes = [
    "Saloon Car",
    "SUV",
    "Pickup",
    "Van"
];


if (!in_array($vehicle_type, $allowedVehicleTypes)) {

    $errors[] =
        "Invalid vehicle type.";
}


// Year
$currentYear = date("Y");


if ($year < 1900 || $year > $currentYear) {

    $errors[] =
        "Invalid year of manufacture.";
}


// Service date
if ($service_date === "") {

    $errors[] =
        "Service date is required.";
}


// Services
if (!is_array($services) || count($services) === 0) {

    $errors[] =
        "At least one service must be selected.";
}


// --------------------------------------------------
// Service price list
// --------------------------------------------------

$servicePrices = [

    "Engine Oil Change" => 3000,

    "Brake Inspection" => 2000,

    "Wheel Alignment" => 3500,

    "Computer Diagnosis" => 2500,

    "Full Service" => 8000,

    // Individualized requirement for last digit 4
    "Tyre Balancing" => 2000

];


// --------------------------------------------------
// Calculate total
// --------------------------------------------------

$totalCost = 0;

$validServices = [];


foreach ($services as $service) {

    if (array_key_exists($service, $servicePrices)) {

        $totalCost += $servicePrices[$service];

        $validServices[] = $service;
    }
}


// Make sure at least one valid service exists
if (count($validServices) === 0) {

    $errors[] =
        "No valid service was selected.";
}


// --------------------------------------------------
// Display errors
// --------------------------------------------------

if (count($errors) > 0) {

?>

    <!DOCTYPE html>

    <html lang="en">

    <head>

        <meta charset="UTF-8">

        <meta name="viewport"
            content="width=device-width, initial-scale=1.0">

        <title>Booking Error</title>

        <link rel="stylesheet"
            href="style.css">

    </head>

    <body>

        <nav class="navbar">

            <div class="logo">
                AutoCare <span>Garage</span>
            </div>

        </nav>


        <div class="confirmation">

            <h1>Booking Error</h1>

            <p>
                Please correct the following problems:
            </p>

            <ul>

                <?php foreach ($errors as $error): ?>

                    <li>
                        <?php echo htmlspecialchars($error); ?>
                    </li>

                <?php endforeach; ?>

            </ul>


            <a href="service.html"
                class="back-btn">

                Return to Booking Form

            </a>

        </div>


    </body>

    </html>

<?php

    exit;
}


// --------------------------------------------------
// Confirmation page
// --------------------------------------------------

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
        content="width=device-width, initial-scale=1.0">

    <title>Service Booking Confirmation</title>

    <link rel="stylesheet"
        href="style.css">

</head>


<body>


    <nav class="navbar">

        <div class="logo">
            AutoCare <span>Garage</span>
        </div>

        <div class="nav-links">

            <a href="index.html">
                Home
            </a>

            <a href="service.html">
                Book Service
            </a>

        </div>

    </nav>


    <div class="confirmation">

        <h1>
            ✓ SERVICE REQUEST RECEIVED
        </h1>


        <table>

            <tr>

                <td>Customer</td>

                <td>
                    <?php
                    echo htmlspecialchars($customer_name);
                    ?>
                </td>

            </tr>


            <tr>

                <td>Phone Number</td>

                <td>
                    <?php
                    echo htmlspecialchars($phone);
                    ?>
                </td>

            </tr>


            <tr>

                <td>Email</td>

                <td>
                    <?php
                    echo htmlspecialchars($email);
                    ?>
                </td>

            </tr>


            <tr>

                <td>Vehicle Registration</td>

                <td>
                    <?php
                    echo htmlspecialchars($registration);
                    ?>
                </td>

            </tr>


            <tr>

                <td>Vehicle Type</td>

                <td>
                    <?php
                    echo htmlspecialchars($vehicle_type);
                    ?>
                </td>

            </tr>


            <tr>

                <td>Vehicle Model</td>

                <td>
                    <?php
                    echo htmlspecialchars($vehicle_model);
                    ?>
                </td>

            </tr>


            <tr>

                <td>Year of Manufacture</td>

                <td>
                    <?php
                    echo htmlspecialchars($year);
                    ?>
                </td>

            </tr>


            <tr>

                <td>Service Date</td>

                <td>
                    <?php
                    echo htmlspecialchars($service_date);
                    ?>
                </td>

            </tr>


            <tr>

                <td>Selected Services</td>

                <td>

                    <ul>

                        <?php foreach ($validServices as $service): ?>

                            <li>

                                <?php

                                echo htmlspecialchars($service);

                                echo " - KSh " .
                                    number_format(
                                        $servicePrices[$service]
                                    );

                                ?>

                            </li>

                        <?php endforeach; ?>

                    </ul>

                </td>

            </tr>


            <tr>

                <td>
                    <strong>ESTIMATED SERVICE COST</strong>
                </td>

                <td class="final-cost">

                    KSh
                    <?php
                    echo number_format($totalCost);
                    ?>

                </td>

            </tr>

        </table>


        <p style="margin-top: 25px;">

            Your service request has been received.
            AutoCare Garage will contact you regarding
            your preferred service date.

        </p>


        <a href="service.html"
            class="back-btn">

            Book Another Service

        </a>

    </div>


    <footer>

        <p>
            &copy; 2026 AutoCare Garage.
            All Rights Reserved.
        </p>

    </footer>


</body>

</html>